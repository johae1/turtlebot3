#!/bin/bash

echo -e "\n########################################################################";
echo "INSTALLING DEPENDENCIES FOR TURTLEBOT3 ROS2"
echo "########################################################################";


PATH_NAME=$(pwd)
XRCE_AGENT_VERSION=v1.1.0
XRCE_CLIENT_VERSION=v1.1.1
XRCE_AGENT_CMAKE_OPTION=
XRCE_CLIENT_CMAKE_OPTION=-DUCLIENT_BUILD_EXAMPLES=ON


echo -e "\n########################################################################";
echo -e "\t Install depenencies for build"
echo "########################################################################";

sudo apt update && sudo apt install build-essential cmake git libboost-all-dev ntpdate


echo -e "\n########################################################################";
echo -e "\t Install udev rules for OpenCR & LDS"
echo "########################################################################";

cd /etc/udev/rules.d/
if [ -f "99-turtlebot3-cdc.rules" ]; then
    sudo rm 99-turtlebot3-cdc.rules*;
fi

sudo wget https://raw.githubusercontent.com/ROBOTIS-GIT/turtlebot3/master/turtlebot3_bringup/99-turtlebot3-cdc.rules
sudo udevadm control --reload-rules
sudo udevadm trigger


echo -e "\n########################################################################";
echo -e "\t Install Micro-XRCE-DDS-Agent"
echo "########################################################################";

cd $PATH_NAME
if [ -d "Micro-XRCE-DDS-Agent" ]; then
    rm -rf Micro-XRCE-DDS-Agent;
fi

git clone https://github.com/eProsima/Micro-XRCE-DDS-Agent.git \
&& cd Micro-XRCE-DDS-Agent && git checkout $XRCE_AGENT_VERSION \
&& mkdir build && cd build \
&& cmake $XRCE_AGENT_CMAKE_OPTION .. \
&& make && sudo make install \
&& sudo ldconfig /usr/local/lib/ 2>&1

if [ $? -ne 0 ]; then
    echo -e "\n [Fail] Micro-XRCE-DDS-Agent Install Fail \n";
    exit 1;
fi


echo -e "\n########################################################################";
echo -e "\t Install Micro-XRCE-DDS-Client & turtlebot3_lidar client"
echo "########################################################################";

cd $PATH_NAME
if [ -d "Micro-XRCE-DDS-Client" ]; then
    rm -rf Micro-XRCE-DDS-Client;
fi

git clone https://github.com/eProsima/Micro-XRCE-DDS-Client.git \
&& cd Micro-XRCE-DDS-Client && git checkout $XRCE_CLIENT_VERSION \
&& cp -rf $PATH_NAME/client.config client.config \
&& cp -rf $PATH_NAME/CMakeLists.txt CMakeLists.txt \
&& cp -rf $PATH_NAME/turtlebot3_lidar examples/turtlebot3_lidar \
&& mkdir build && cd build \
&& cmake $XRCE_CLIENT_CMAKE_OPTION .. \
&& make && sudo make install \
&& cp examples/turtlebot3_lidar/turtlebot3_lidar $PATH_NAME/turtlebot3_lidar_xrce_client 2>&1

if [ $? -ne 0 ]; then
    echo -e "\n [Fail] Micro-XRCE-DDS-Client Install Fail \n";
    exit 1;
fi


echo -e "\n########################################################################";
echo -e "\t Complete!"
echo "########################################################################";


exit
