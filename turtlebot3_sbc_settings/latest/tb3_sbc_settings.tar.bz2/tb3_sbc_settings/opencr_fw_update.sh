#!/usr/bin/env bash

echo -e "\n########################################################################";
echo "UPDATE OPENCR F/W FOR TURTLEBOT3 CORE"
echo "########################################################################";

if (($#==2))
then
  cd opencr_update
  ./update.sh $1 $2
else
  echo "wrong parameter "
  echo "./opencr_fw_update.sh <port> [burger|waffle]"
fi

exit
