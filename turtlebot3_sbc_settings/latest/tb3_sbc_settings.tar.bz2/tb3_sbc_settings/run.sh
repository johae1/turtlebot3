#!/usr/bin/env bash

echo -e "\n########################################################################";
echo "Run two Agent and one Client for LDS & OpenCR"
echo "########################################################################";

if [ -f "nohup.out" ]; then
    rm -rf nohup.out
fi

(nohup MicroXRCEAgent serial --dev /dev/ttyACM0 -b 1000000 -r tb3_fastrtps_profile.refs -v 5) & \
(nohup MicroXRCEAgent udp -p 2019 -r tb3_fastrtps_profile.refs -v 5) & \
(sleep 1; nohup ./turtlebot3_lidar_xrce_client) &

sleep 3;

echo -e "\nTwo MicroXRCEAgents and one MicroXRCEClient listed below are running in the background."
echo "Please refer to the note below to check its execution status or to terminate it."

echo -e "";
echo -e "========== NOTE =========="
echo "This script uses the nohup command to run multiple processes in the background."
echo "Therefore, to terminate these processes, use the kill command like below"
echo -e "\n use 'ps | grep \"MicroXRCEAgent\"' command for checking process ID"
echo -e " kill [PID number]\n"
echo "Also, logs running in the background are stored in nohup.out in the current folder where this command was executed."
echo -e "==========================\n"

exit

